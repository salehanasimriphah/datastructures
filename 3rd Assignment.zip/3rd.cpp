#include <iostream>
#include <string>
#include <stack>
using namespace std;

// Node structure
struct Node {
    char data;
    Node* left;
    Node* right;
};

// Create new node
Node* createNode(char data) {
    Node* newNode = new Node;
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    return newNode;
}

// Check if operator
bool isOperator(char c) {
    return (c == '+' || c == '-' || c == '*' || c == '/');
}

// Function to check precedence (for infix)
int precedence(char c) {
    if (c == '*' || c == '/') return 2;
    if (c == '+' || c == '-') return 1;
    return -1;
}

// Infix to Postfix conversion
string infixToPostfix(string infix) {
    stack<char> st;
    string postfix = "";

    for (int i = 0; i < infix.length(); i++) {
        char ch = infix[i];
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z'))
            postfix += ch;
        else if (ch == '(')
            st.push(ch);
        else if (ch == ')') {
            while (!st.empty() && st.top() != '(') {
                postfix += st.top();
                st.pop();
            }
            if (!st.empty()) st.pop();
        } else if (isOperator(ch)) {
            while (!st.empty() && precedence(st.top()) >= precedence(ch)) {
                postfix += st.top();
                st.pop();
            }
            st.push(ch);
        }
    }

    while (!st.empty()) {
        postfix += st.top();
        st.pop();
    }

    return postfix;
}

// Prefix to Postfix conversion
string prefixToPostfix(string prefix) {
    stack<string> st;
    for (int i = prefix.length() - 1; i >= 0; i--) {
        char ch = prefix[i];
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
            string s(1, ch);
            st.push(s);
        } else if (isOperator(ch)) {
            string op1 = st.top(); st.pop();
            string op2 = st.top(); st.pop();
            string temp = op1 + op2 + ch;
            st.push(temp);
        }
    }
    return st.top();
}

// Build Expression Tree from Postfix
Node* buildTreeFromPostfix(string postfix) {
    stack<Node*> st;
    for (int i = 0; i < postfix.size(); i++) {
        char ch = postfix[i];
        if (!isOperator(ch)) {
            st.push(createNode(ch));
        } else {
            Node* node = createNode(ch);
            node->right = st.top(); st.pop();
            node->left = st.top(); st.pop();
            st.push(node);
        }
    }
    return st.top();
}

// Traversals
void inorder(Node* root) {
    if (root == NULL) return;
    if (isOperator(root->data)) cout << "(";
    inorder(root->left);
    cout << root->data;
    inorder(root->right);
    if (isOperator(root->data)) cout << ")";
}

void preorder(Node* root) {
    if (root == NULL) return;
    cout << root->data;
    preorder(root->left);
    preorder(root->right);
}

void postorder(Node* root) {
    if (root == NULL) return;
    postorder(root->left);
    postorder(root->right);
    cout << root->data;
}

// Main Program with Switch Menu
int main() {
    int choice;
    string expression, postfix;
    Node* root = NULL;

    do {
        cout << "\n--- Expression Conversion Menu ---\n";
        cout << "1. Postfix to Infix & Prefix\n";
        cout << "2. Prefix to Infix & Postfix\n";
        cout << "3. Infix to Prefix & Postfix\n";
        cout << "4. Exit\n";
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                cout << "Enter Postfix Expression (e.g. ab+c* ): ";
                cin >> expression;
                root = buildTreeFromPostfix(expression);
                break;
            }

            case 2: {
                cout << "Enter Prefix Expression (e.g. *+abc ): ";
                cin >> expression;
                postfix = prefixToPostfix(expression);
                root = buildTreeFromPostfix(postfix);
                break;
            }

            case 3: {
                cout << "Enter Infix Expression (e.g. (a+b)*c ): ";
                cin >> expression;
                postfix = infixToPostfix(expression);
                root = buildTreeFromPostfix(postfix);
                break;
            }

            case 4:
                cout << "Exiting program...\n";
                return 0;

            default:
                cout << "Invalid choice! Try again.\n";
                continue;
        }

        // Display Results
        cout << "\n--- Results ---\n";
        cout << "Infix Expression: ";
        inorder(root);
        cout << endl;

        cout << "Prefix Expression: ";
        preorder(root);
        cout << endl;

        cout << "Postfix Expression: ";
        postorder(root);
        cout << endl;

    } while (choice != 4);

    return 0;
}

