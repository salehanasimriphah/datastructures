#include<iostream>
using namespace std;

class Calculator{
	
private:
	Calculator(){	
	}
	
public:
	static int operationCount;
	
	static int sum(int a, int b){
		operationCount++;
		return a+b;
	}	
	
	static int difference(int a, int b){
		operationCount++;
		return a-b;
	}
	
	static double division(double a, double b){
		operationCount++;
		if(b == 0){
			cout<<"ERROR: Can't divide by 0."<<endl;
		}
		else{
			return a/b;
		}
	}
	
	static int remainder(int a, int b){
		operationCount++;
		if(b == 0){
			cout<<"ERROR: Can't divide by 0."<<endl;
		}
		else{
			return a%b;
		}
	}
	
	static double percentage(double first_number, double second_number){
		operationCount++;
		if(second_number == 0){
			cout<<"ERROR: Can't divide by 0."<<endl;
		}
		else{
			return first_number/second_number *100;
		}
	}
	
	static int getOperationCount(){	
		return operationCount;
	}
};

int Calculator::operationCount=0;
int main(){
	
	int a = 79, b = 15;
	cout<<"Sum is: "<<Calculator::sum(a,b)<<endl;
	cout<<"Difference is: "<<Calculator::difference(a,b)<<endl;
	cout<<"Division is: "<<Calculator::division(a,b)<<endl;
	cout<<"Remainder is: "<<Calculator::remainder(a,b)<<endl;
	cout<<"Percentage is: "<<Calculator::percentage(a,b)<<endl;
	
	cout<<"Operation performed are: "<<Calculator::getOperationCount();
	return 0;
}

