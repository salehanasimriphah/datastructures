#include<iostream>
using namespace std;
struct Node{
	int data;
	Node* next;
	Node* prev;
};

void display(Node* head){
	Node* temp = head;
	while(temp != NULL){
		cout<<temp->data<<" ";
		temp = temp->next;
	}
	cout<<endl<<endl;
}

void insertionPosition(Node*& head, int val, int pos){
	Node* newNode = new Node();
	newNode->data = val;
	newNode->next = NULL;
	newNode->prev = NULL;
	
	if(pos == 1){
		newNode->next = head;
		if(head != NULL){
			head->prev = newNode;
		}
		head = newNode;
		return;
	}
	
	Node* temp = head;
	int count = 1;
	
	while(count<pos-1 && temp!=NULL){
		temp= temp->next;
		count++;
	}
	if(temp == NULL){
		cout<<"Invalid Position. List is not this big enough"<<endl;
		delete newNode;
	}
	
	newNode->next = temp->next;
	newNode->prev = temp;
	
	if(temp->next != NULL){
		temp->next->prev = newNode;
	}
	
	temp->next = newNode; 
}

void deletionPosition(Node*& head, int pos){
	if(head == NULL){
		cout<<"List is empty. Nothing to delete."<<endl;
		return;
	}
	
	if(pos == 1){
		Node* temp = head;       
    	head = head->next;       
    	if (head != NULL) {
        	head->prev = NULL; 
    	}
    cout << "Deleting " << temp->data << endl;
    delete temp;
    return;
	}
	
	Node* temp = head;
	for (int i=1; i<pos && temp!=NULL; i++){
        temp = temp->next;
    }
    if(temp == NULL){
        cout<<"Position out of range!"<<endl;
        return;
    }
    
    if(temp->prev != NULL){
    	if(temp->next != NULL){
        	temp->prev->next = temp->next;   
        	temp->next->prev = temp->prev;   
    	}
		else {
        	temp->prev->next = NULL;      
    	}
	}
    cout<<"Deleting "<<temp->data<<endl;
    delete temp;
}

int main() {
    Node* head = NULL;

    insertionPosition(head,10,1);
    insertionPosition(head,20,2);
    insertionPosition(head,30,3);
    insertionPosition(head,50,4);
    
    cout<<"List before deletion: "<<endl;
    display(head);

    deletionPosition(head,2);
    cout<<"List after deletion: "<<endl;
    display(head);

	cout<<"Trying to delete node at the 5 position: "<<endl;
    deletionPosition(head,5); 

    return 0;
}
