#include <iostream>
using namespace std;

struct Node {
    int data;
    Node* prev;
    Node* next;
};

void deleteAtBeginning(Node*& head){
    if(head==NULL){
        cout<<"List is empty!"<<endl;
        return;
    }
    Node* temp=head;
    head=head->next;
    if(head!=NULL) head->prev=NULL;
    delete temp;
    cout<<"Node deleted from beginning."<<endl;
}

void deleteAtEnd(Node*& head){
    if(head==NULL){
        cout<<"List is empty!"<<endl;
        return;
    }
    Node* temp=head;
    if(head->next==NULL){
        head=NULL;
        delete temp;
        cout<<"Node deleted from end."<<endl;
        return;
    }
    while(temp->next!=NULL) temp=temp->next;
    temp->prev->next=NULL;
    delete temp;
    cout<<"Node deleted from end."<<endl;
}

void deleteAtPosition(Node*& head,int pos){
    if(head==NULL){
        cout<<"List is empty!"<<endl;
        return;
    }
    if(pos<=0){
        cout<<"Invalid position!"<<endl;
        return;
    }
    Node* temp=head;
    if(pos==1){
        deleteAtBeginning(head);
        return;
    }
    for(int i=1;i<pos&&temp!=NULL;i++) temp=temp->next;
    if(temp==NULL){
        cout<<"Position out of range!"<<endl;
        return;
    }
    if(temp->next!=NULL) temp->next->prev=temp->prev;
    if(temp->prev!=NULL) temp->prev->next=temp->next;
    delete temp;
    cout<<"Node deleted from position "<<pos<<"."<<endl;
}

void display(Node* head){
    Node* temp=head;
    cout<<"Doubly Linked List: ";
    while(temp!=NULL){
        cout<<temp->data<<" <-> ";
        temp=temp->next;
    }
    cout<<"NULL"<<endl;
}

int main(){
    Node* head=NULL;
    head=new Node{10,NULL,NULL};
    head->next=new Node{20,head,NULL};
    head->next->next=new Node{30,head->next,NULL};
    head->next->next->next=new Node{40,head->next->next,NULL};
    int choice,pos;
    do{
        cout<<"\n----MENU----"<<endl;
        cout<<"1. Delete at Beginning\n";
        cout<<"2. Delete at End\n";
        cout<<"3. Delete at Position\n";
        cout<<"4. Display\n";
        cout<<"5. Exit\n";
        cout<<"Enter your choice: ";
        cin>>choice;
        switch(choice){
            case 1: deleteAtBeginning(head); break;
            case 2: deleteAtEnd(head); break;
            case 3: cout<<"Enter position: "; cin>>pos; deleteAtPosition(head,pos); break;
            case 4: display(head); break;
            case 5: cout<<"Exiting\n"; break;
            default: cout<<"Invalid choice!\n";
        }
    }while(choice!=5);
    return 0;
}

